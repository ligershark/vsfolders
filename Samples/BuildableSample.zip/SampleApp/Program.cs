﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectToBuild
{
    class Program
    {
        static void Main(string[] args)
        {
            var refs = new object[]
            {
                new RandomAssembly.RandomClass1()
                //new RandomAssembly2.RandomClass2()
            };

            foreach (var obj in refs)
                Console.WriteLine(obj.GetType());

            Console.WriteLine("Nice...");
            Console.ReadLine();
        }
    }
}
